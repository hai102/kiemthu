package vn.fpoly;

public class Bai6 {
    public static Integer timMin(Integer[] arr) {
        if (arr == null || arr.length == 0) {
            throw new IllegalArgumentException("Mảng không được rỗng hoặc null");
        }

        int min = arr[0]; // Giả sử phần tử đầu tiên là nhỏ nhất ban đầu
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min) {
                min = arr[i];
            }
        }
        return min;
    }
}
