package vn.fpoly;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class Bai2_Test {
    Bai2 service = new Bai2();

    @Test
    public void test01() {
        int result = service.bai2TinhThuong(5, 5);
        assertEquals(1, result);
    }

    @Test
    public void test02() {
        int result = service.bai2TinhThuong(10, 2);
        assertEquals(5, result);
    }

    @Test
    public void test03() {
        assertThrows(ArithmeticException.class, () -> service.bai2TinhThuong(5, 0));
    }

    @Test
    public void test04() {
        int result = service.bai2TinhThuong(3, 5);
        assertEquals(0, result);
    }

    @Test
    public void test05() {
        int result = service.bai2TinhThuong(-10, 2);
        assertEquals(-5, result);
    }

    @Test
    public void test06() {
        int result = service.bai2TinhThuong(7, 3);
        assertEquals(2, result);
    }

    @Test
    public void test07() {
        int result = service.bai2TinhThuong(0, 5);
        assertEquals(0, result);
    }

    @Test
    public void test08() {
        int result = service.bai2TinhThuong(Integer.MAX_VALUE, 1);
        assertEquals(Integer.MAX_VALUE, result);
    }

    @Test
    public void test09() {
        int result = service.bai2TinhThuong(Integer.MIN_VALUE, -1);
        assertEquals(Integer.MIN_VALUE, result);
    }

    @Test
    public void test10() {
        int result = service.bai2TinhThuong(-7,-3);
        assertEquals(2, result);
    }
}