package vn.fpoly;

import java.util.List;

public class Bai4 {
    public int GetElementAtIndex(List<Integer> array, int index) {
        if (array == null || index < 0 || index >= array.size()) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for array of size " + (array == null ? 0 : array.size()));
        }
        return array.get(index);
    }
}
