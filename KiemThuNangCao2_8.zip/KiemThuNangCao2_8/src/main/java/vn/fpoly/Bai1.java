package vn.fpoly;

public class Bai1 {
    public int bai1TinhTich(int a, int b) {
        if (!laSoNguyen(a) || !laSoNguyen(b)) {
            throw new IllegalArgumentException("a và b phải là số nguyên.");
        }
        return a * b;
    }

    private boolean laSoNguyen(int n) {
        return n == (int) n;
    }
}
