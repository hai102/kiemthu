package vn.fpoly;

public class Bai2 {
    public int bai2TinhThuong(int a, int b){
        if (b == 0) {
            throw new ArithmeticException("Không thể chia cho 0");
        }
        return a / b;
    }
}
