package vn.fpoly;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class Bai6_Test {

    private Bai6 service = new Bai6();

    @Test
    void testTimMin_ValidArray_ReturnsMin() {
        Integer[] arr = {5, 2, 8, 1, 9};
        assertEquals(1, service.timMin(arr));
    }

    @Test
    void testTimMin_EmptyArray_ThrowsIllegalArgumentException() {
        Integer[] arr = {};
        assertThrows(IllegalArgumentException.class, () -> service.timMin(arr));
    }

    @Test
    void testTimMin_NullArray_ThrowsIllegalArgumentException() {
        Integer[] arr = null;
        assertThrows(IllegalArgumentException.class, () -> service.timMin(arr));
    }

    @Test
    void testTimMin_SingleElementArray_ReturnsElement() {
        Integer[] arr = {7};
        assertEquals(7, service.timMin(arr));
    }

    @Test
    void testTimMin_ArrayWithDuplicates_ReturnsMin() {
        Integer[] arr = {5, 2, 8, 2, 9, 1};
        assertEquals(1, service.timMin(arr));
    }

    @Test
    void testTimMin_ArrayWithNegativeNumbers_ReturnsMin() {
        Integer[] arr = {-5, -2, -8, -1, -9};
        assertEquals(-9, service.timMin(arr));
    }
}