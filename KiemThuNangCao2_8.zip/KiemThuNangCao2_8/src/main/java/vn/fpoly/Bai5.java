package vn.fpoly;

public class Bai5 {
    public class UserProfile {
        private String name;

        public UserProfile(String name) {
            this.name = name;
        }

        public String GetName() {
            if (this.name == null) {
                throw new NullPointerException("Hồ sơ người dùng chưa được khởi tạo.");
            }
            return this.name;
        }
    }
}
