package vn.fpoly;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class Bai4_Test {
    Bai4 service = new Bai4();

    @Test
    public void testIndexOutOfBoundsThrowsException() {
        List<Integer> array = new ArrayList<>();
        array.add(10);
        array.add(20);

        assertThrows(IndexOutOfBoundsException.class, () -> service.GetElementAtIndex(array, 5));
        assertThrows(IndexOutOfBoundsException.class, () -> service.GetElementAtIndex(array, -1));
    }

    @Test
    public void testNullArrayThrowsException() {
        List<Integer> array = null;

        assertThrows(NullPointerException.class, () -> service.GetElementAtIndex(array, 0));
    }

    @Test
    public void testValidIndex() {
        List<Integer> array = new ArrayList<>();
        array.add(10);
        array.add(20);

        int element = service.GetElementAtIndex(array, 1);
        assertEquals(20, element);
    }
}
