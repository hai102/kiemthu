package vn.fpoly;

import org.junit.Test;

import static org.junit.Assert.assertThrows;

public class Bai5_Test {
    @Test
    public void testGetName_NullProfile_ThrowsNullPointerException() {
        Bai5.UserProfile profile = null;

        assertThrows(NullPointerException.class, () -> {
            String name = profile.GetName();
        });
    }
}
