package vn.fpoly;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class Bai3_Test {
    Bai3 service = new Bai3();

    @Test
    public void testEmptyListThrowsException() {
        List<Integer> emptyList = new ArrayList<>();

        assertThrows(ArithmeticException.class, () -> service.tinhTrungBinh(emptyList));
    }

    @Test
    public void testNullListThrowsException() {
        List<Integer> nullList = null;

        assertThrows(NullPointerException.class, () -> service.tinhTrungBinh(nullList));
    }


    @Test
    public void testListWithNullElementThrowsException() {
        List<Integer> listWithNull = new ArrayList<>();
        listWithNull.add(1);
        listWithNull.add(null);
        listWithNull.add(2);

        assertThrows(NullPointerException.class, () -> service.tinhTrungBinh(listWithNull));
    }


    @Test
    public void testValidList() {
        List<Integer> validList = new ArrayList<>();
        validList.add(1);
        validList.add(2);
        validList.add(3);

        double average = service.tinhTrungBinh(validList);
        assertEquals(2.0, average, 0.001);
    }

    @Test
    public void testSingleItemList() {
        List<Integer> singleItemList = new ArrayList<>();
        singleItemList.add(5);

        double average = service.tinhTrungBinh(singleItemList);
        assertEquals(5.0, average, 0.001);
    }
}
