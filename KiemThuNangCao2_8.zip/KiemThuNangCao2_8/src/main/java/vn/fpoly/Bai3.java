package vn.fpoly;

import java.util.List;

public class Bai3 {
    public double tinhTrungBinh(List<Integer> numbers) {
        if (numbers == null || numbers.isEmpty()) {
            throw new ArithmeticException("Không thể tính toán nếu danh sách trống!");
        }

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }
        return (double) sum / numbers.size();
    }
}
