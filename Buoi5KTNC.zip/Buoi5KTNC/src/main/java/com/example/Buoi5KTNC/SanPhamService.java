package com.example.Buoi5KTNC;

import java.util.ArrayList;
import java.util.List;

public class SanPhamService {
    private List<SanPham> danhSachSanPham = new ArrayList<>();

    public void themSanPham(SanPham sp) {
        danhSachSanPham.add(sp);
    }

    public boolean xoaSanPham(String ten) {
        return danhSachSanPham.removeIf(sp -> sp.getTen().equalsIgnoreCase(ten));
    }

    public int getSoLuongSanPham() {
        return danhSachSanPham.size();
    }
}
