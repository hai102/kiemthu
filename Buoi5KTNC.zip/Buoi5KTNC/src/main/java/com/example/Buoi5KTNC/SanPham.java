package com.example.Buoi5KTNC;

public class SanPham {
    private String ten;
    private int namBaoHanh;
    private float gia;
    private int soLuong;
    private String danhMuc;

    public SanPham(String ten, int namBaoHanh, float gia, int soLuong, String danhMuc) {
        this.ten = ten;
        this.namBaoHanh = namBaoHanh;
        this.gia = gia;
        this.soLuong = soLuong;
        this.danhMuc = danhMuc;
    }

    public String getTen() {
        return ten;
    }
}
