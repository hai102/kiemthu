package On;

import com.example.Buoi5KTNC.MathUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import java.time.Duration;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class Phan1 {
//    public static void main(String[] args) {
//
//        //Khởi tạo browser với Chrome
//        WebDriver driver;
//        driver = new ChromeDriver();
//        driver.manage().window().maximize();
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//
//        //Mở trang anhtester.com
//        driver.get("https://anhtester.com/");
//
//        //Click nút Login
//        driver.findElement(By.xpath("//a[@id='btn-login']")).click();
//
//        //Tắt browser
//        driver.quit();
//    }
    private MathUtils  math = new MathUtils();
        @Test
        void testPrimeNumbers() {
            assertTrue(math.isPrime(2));  // 2 là số nguyên tố
            assertTrue(math.isPrime(3));  // 3 là số nguyên tố
            assertTrue(math.isPrime(5));  // 5 là số nguyên tố
        }

        @Test
        void testNonPrimeNumbers() {
            assertFalse(math.isPrime(1));  // 1 không phải số nguyên tố
            assertFalse(math.isPrime(4));  // 4 không phải số nguyên tố
            assertFalse(math.isPrime(9));  // 9 không phải số nguyên tố
        }

        @Test
        void testNegativeNumbers() {
            assertFalse(math.isPrime(-5)); // Số âm không phải số nguyên tố
            assertFalse(math.isPrime(-1)); // Số âm không phải số nguyên tố
        }
}
