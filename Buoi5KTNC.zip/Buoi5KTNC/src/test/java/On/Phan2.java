package On;

import static org.junit.jupiter.api.Assertions.*;

import com.example.Buoi5KTNC.SanPham;
import com.example.Buoi5KTNC.SanPhamService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class Phan2 {
    private SanPhamService sanPhamService;

    @BeforeEach
    void setUp() {
        sanPhamService = new SanPhamService();
        sanPhamService.themSanPham(new SanPham("Laptop", 2, 1500.0f, 10, "Điện tử"));
        sanPhamService.themSanPham(new SanPham("Điện thoại", 1, 800.0f, 5, "Điện tử"));
    }

    @Test
    void testXoaSanPhamThanhCong() {
        assertTrue(sanPhamService.xoaSanPham("Laptop"));
        assertEquals(1, sanPhamService.getSoLuongSanPham());
    }

    @Test
    void testXoaSanPhamKhongTonTai() {
        assertFalse(sanPhamService.xoaSanPham("Máy giặt"));
        assertEquals(2, sanPhamService.getSoLuongSanPham());
    }
}
